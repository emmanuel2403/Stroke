//let hero;


function setup() {
  createCanvas(700,400);
  //hero = loadImage("hero/Mind.png")

}

function draw() {
 // background("maroon");
 // image (hero, 0, 0, 700, 400);
  //text ("Unlock Your Mind", 150, 100);
  //textSize(50);
}
